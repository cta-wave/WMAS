module.exports = require("./lib/webidl2.js");
