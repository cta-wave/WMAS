This directory contains Chromium-specific test resources.

The files `mojo_bindings.js` and `*.mojom.js` are manually copied from the
Chromium build process's generated files and should not be edited manually.
