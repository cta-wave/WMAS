
# pywebsocket #

The pywebsocket project aims to provide a [WebSocket](https://tools.ietf.org/html/rfc6455) standalone server and a WebSocket extension for [Apache HTTP Server](https://httpd.apache.org/), mod\_pywebsocket.

pywebsocket is intended for **testing** or **experimental** purposes.

Please see [Wiki](../../wiki) for more details.
