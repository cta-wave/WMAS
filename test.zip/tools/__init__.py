from . import localpaths as _localpaths  # noqa: F401
