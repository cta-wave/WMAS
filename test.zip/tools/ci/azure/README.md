These are step templates for Azure Pipelines, used in `.azure-pipelines.yml`
in the root of the repository.
