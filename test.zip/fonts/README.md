This directory only contains auxiliary font files used by other tests. See
/css-fonts for tests covering the CSS Fonts Module specification.

The font named `Ahem.ttf` is referenced from the project documentation and the
CLI's scripts for provisioning virtual machines provided by Sauce Labs. If that
file is re-located, the references should be updated accordingly.
