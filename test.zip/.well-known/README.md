Well-Known URI Testing
======================

This directory is used for testing resources that are loaded based on the
well-known URI standard. [[RFC5785](https://tools.ietf.org/html/rfc5785)]

For other kinds of resource files, they should either be placed at
[/common](../common) or the respective subdirectories for the
particular standard.
