const results = {
    "BackgroundSync": {
        "pass": 0,
        "fail": 1,
        "timeout": 0,
        "not_run": 0,
        "total": 1,
        "complete": 1
    }
}